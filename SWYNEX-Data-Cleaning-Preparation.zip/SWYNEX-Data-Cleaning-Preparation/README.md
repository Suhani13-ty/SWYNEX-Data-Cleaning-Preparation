# SWYNEX — Data Cleaning & Preparation (Task 1)

## Project overview
This beginner-friendly project demonstrates cleaning a small customer dataset using Python and pandas.

**Important:** The included CSV is an illustrative sample dataset created for this demonstration, not an external public dataset. If SWYNEX specifically requires a public dataset, replace it with one from a public source and cite that source before submitting.

## Files
- `raw_customer_data.csv` — sample raw data containing data-quality issues.
- `cleaned_customer_data.csv` — cleaned output.
- `data_cleaning.py` — reproducible Python cleaning script.
- `cleaning_report.txt` — summary of the changes.
- `requirements.txt` — Python dependency.

## Data-quality issues addressed
1. **Duplicate records:** removed exact duplicate rows.
2. **Missing/invalid values:** blank age and the text `not available` in salary were treated as missing.
3. **Incorrect data types:** age and salary converted to numeric values; signup dates parsed as dates.
4. **Invalid value:** age `200` was treated as invalid and replaced using the median age.
5. **Inconsistent categories:** gender values such as `female`, `F`, `FEMALE`, and `M` standardized.
6. **Inconsistent text formatting:** extra spaces removed and city names normalized to title case.
7. **Date formatting:** signup dates standardized to `YYYY-MM-DD`.

## How to run
Install Python 3, then in this folder run:

```bash
pip install -r requirements.txt
python data_cleaning.py
```

The script regenerates `cleaned_customer_data.csv` and `cleaning_report.txt`.

## Tools
- Python
- pandas

## Review before submission
- Confirm that your internship accepts a sample dataset. If a public dataset is mandatory, use a real public dataset and add its source and license here.
- Upload this folder to a **public** GitHub repository.
- Add a screenshot of the raw/cleaned data or the cleaning report to your LinkedIn post.
- Mention `@SWYNEX Technologies`, select the official company page, and use relevant hashtags such as `#SWYNEX #Internship`.
- Test both links in an incognito/private window before submitting.
