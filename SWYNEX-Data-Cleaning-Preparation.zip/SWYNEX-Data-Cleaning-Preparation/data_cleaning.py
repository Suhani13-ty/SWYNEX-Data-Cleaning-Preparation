"""
SWYNEX Data Cleaning & Preparation - Task 1
Run: python data_cleaning.py
Requirements: pandas
This project uses an illustrative sample dataset created for demonstration.
"""

from pathlib import Path
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
INPUT_FILE = BASE_DIR / "raw_customer_data.csv"
OUTPUT_FILE = BASE_DIR / "cleaned_customer_data.csv"
REPORT_FILE = BASE_DIR / "cleaning_report.txt"

df = pd.read_csv(INPUT_FILE)
initial_rows = len(df)

# 1) Remove exact duplicate records.
df = df.drop_duplicates()
duplicates_removed = initial_rows - len(df)

# 2) Normalize text fields (trim extra spaces).
for col in ["name", "gender", "city", "email", "customer_id"]:
    df[col] = df[col].astype("string").str.strip()

# 3) Standardize inconsistent category values.
gender_map = {
    "m": "Male", "male": "Male",
    "f": "Female", "female": "Female",
    "other": "Other"
}
df["gender"] = df["gender"].str.lower().map(gender_map).fillna("Unknown")

df["city"] = df["city"].str.title()

# 4) Convert numeric columns and replace invalid values with missing values.
df["age"] = pd.to_numeric(df["age"], errors="coerce")
df.loc[~df["age"].between(0, 120), "age"] = pd.NA
df["salary"] = (
    df["salary"].astype("string").str.strip()
      .replace({"": pd.NA, "not available": pd.NA, "N/A": pd.NA, "na": pd.NA})
)
df["salary"] = pd.to_numeric(df["salary"], errors="coerce")

# 5) Parse dates with mixed formats.
df["signup_date"] = pd.to_datetime(df["signup_date"], errors="coerce", dayfirst=True)

# 6) Fill missing numeric values using median (simple demonstration choice).
age_median = df["age"].median()
salary_median = df["salary"].median()
df["age"] = df["age"].fillna(age_median)
df["salary"] = df["salary"].fillna(salary_median)

# 7) Export date consistently as YYYY-MM-DD and save clean CSV.
df["signup_date"] = df["signup_date"].dt.strftime("%Y-%m-%d")
df.to_csv(OUTPUT_FILE, index=False)

report = f"""SWYNEX Task 1 - Cleaning Report
--------------------------------
Rows before cleaning: {initial_rows}
Exact duplicate rows removed: {duplicates_removed}
Rows after duplicate removal: {len(df)}
Missing/invalid ages filled with median: {int(df['age'].isna().sum())} remaining missing
Missing/invalid salaries filled with median: {int(df['salary'].isna().sum())} remaining missing
Gender values standardized: Male, Female, Other, Unknown
City names standardized to title case
Age and salary converted to numeric types
Signup dates standardized to YYYY-MM-DD
Output file: {OUTPUT_FILE.name}

Note: This repository includes a small illustrative sample dataset for learning.
If your internship requires a public external dataset, replace the sample with a public dataset
and document its source/license before submission.
"""
REPORT_FILE.write_text(report, encoding="utf-8")
print(report)
